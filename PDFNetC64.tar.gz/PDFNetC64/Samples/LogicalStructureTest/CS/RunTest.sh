#!/bin/sh
dotnet run
exit $?
